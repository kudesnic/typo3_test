.. include:: Includes.txt

.. _labels-for-crossreferencing:

============================
Labels for cross-referencing
============================

.. ref-targets-list::

