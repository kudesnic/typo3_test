:orphan:

.. include:: Includes.txt

============
ChangeLog v7
============

Every change to the TYPO3 Core which might affect your site is documented here.

.. toctree::
   :titlesonly:

   Changelog/7.6.x/Index
   Changelog/7.6/Index
   Changelog/7.5/Index
   Changelog/7.4/Index
   Changelog/7.3/Index
   Changelog/7.2/Index
   Changelog/7.1/Index
   Changelog/7.0/Index
