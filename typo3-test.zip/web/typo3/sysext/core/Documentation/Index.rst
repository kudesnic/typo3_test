
.. include:: Includes.txt

===========================
TYPO3 CMS Core ChangeLog v8
===========================

:Rendered: |today|

Every change to the TYPO3 Core which might affect your site is documented here.

.. toctree::
   :hidden:

   Sitemap/Index
   Changelog-8
   Changelog-7
   Changelog/Howto
