<?php
$EM_CONF[$_EXTKEY] = [
    'title' => 'Internal notes',
    'description' => 'Records with messages which can be placed on any page and contain instructions or other information related to a page or section.',
    'category' => 'be',
    'state' => 'stable',
    'uploadfolder' => 0,
    'createDirs' => '',
    'clearCacheOnLoad' => 0,
    'author' => 'TYPO3 Core Team',
    'author_email' => 'typo3cms@typo3.org',
    'author_company' => '',
    'version' => '8.7.19',
    'constraints' => [
        'depends' => [
            'php' => '7.0.0-7.2.99',
            'typo3' => '8.7.19',
        ],
        'conflicts' => [],
        'suggests' => [],
    ],
];
