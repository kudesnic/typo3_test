<?php

require __DIR__ . '/sysext/backend/Resources/Private/Php/backend.php';
